
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  username: String,
  password: String,
  name: String,
  email: String,
  photo: String,
  location: String,
  isPublic: { type: Boolean, default: true },
  skillsOffered: [String],
  skillsWanted: [String],
  availability: [String],
  isAdmin: { type: Boolean, default: false },
  rating: { type: Number, default: 0 },
  ratingCount: { type: Number, default: 0 },
});

module.exports = mongoose.model('User', userSchema);
