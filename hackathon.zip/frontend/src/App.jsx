
import { useEffect, useState } from 'react';
import axios from 'axios';

function App() {
  const [user, setUser] = useState(null);
  const [form, setForm] = useState({ username: '', password: '' });
  const [registerMode, setRegisterMode] = useState(false);

  useEffect(() => {
    axios.get('/auth/user', { withCredentials: true })
      .then(res => setUser(res.data))
      .catch(() => setUser(null));
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const url = registerMode ? '/auth/register' : '/auth/login';
    const res = await axios.post(url, form, { withCredentials: true });
    setUser(res.data);
  };

  const logout = () => {
    axios.post('/auth/logout', {}, { withCredentials: true }).then(() => setUser(null));
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Skill Swap Platform</h1>
      {user ? (
        <>
          <p>Welcome, {user.name}</p>
          <button onClick={logout} className="mt-4 bg-red-500 text-white px-4 py-2 rounded">Logout</button>
        </>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          <input type="text" placeholder="Username" className="border p-2" onChange={e => setForm({ ...form, username: e.target.value })} />
          <input type="password" placeholder="Password" className="border p-2" onChange={e => setForm({ ...form, password: e.target.value })} />
          <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">
            {registerMode ? 'Register' : 'Login'}
          </button>
          <button type="button" onClick={() => setRegisterMode(!registerMode)} className="text-sm underline block">
            {registerMode ? 'Switch to Login' : 'Switch to Register'}
          </button>
        </form>
      )}
    </div>
  );
}

export default App;
