
const router = require('express').Router();
const User = require('../models/User');
const bcrypt = require('bcrypt');

router.post('/register', async (req, res) => {
  const { username, password, name, email } = req.body;
  const existing = await User.findOne({ username });
  if (existing) return res.status(400).send('Username already exists');
  const hash = await bcrypt.hash(password, 10);
  const user = new User({ username, password: hash, name, email });
  await user.save();
  req.session.userId = user._id;
  res.status(201).json(user);
});

router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username });
  if (!user) return res.status(400).send('Invalid credentials');
  const match = await bcrypt.compare(password, user.password);
  if (!match) return res.status(400).send('Invalid credentials');
  req.session.userId = user._id;
  res.json(user);
});

router.post('/logout', (req, res) => {
  req.session.destroy();
  res.sendStatus(200);
});

router.get('/user', async (req, res) => {
  const user = await User.findById(req.session.userId);
  if (!user) return res.sendStatus(401);
  res.json(user);
});

module.exports = router;
