
const router = require('express').Router();
const User = require('../models/User');

router.post('/profile', async (req, res) => {
  const user = await User.findByIdAndUpdate(req.session.userId, req.body, { new: true });
  if (!user) return res.status(401).send('Unauthorized');
  res.json(user);
});

module.exports = router;
